# HADAPOP- Comentarios Entrega 2

## Git
- La etiqueta ENCAD es correcta
- El deadline2 esta creado pero no esta cerrado
- Cread y definid bien las issues, cuanto mejor sea el detalle, mejor ira todo durante el desarrollo.

## EN
- Las EN están implementadas y llaman a las CAD. Buen trabajo,
- Recodad que todas las EN tiene que tener los atributos correspondientes.

## Esquema de la BBDD
- No veo dónde se van a guardar las compras o las ventas. No sé como tenéis pensado hacer esto pero echo en falta alguna tabla donde se guarden las compras o las ventas.

## Proyecto
- No he podido abrir correctamente el proyecto library.
- El error que me sale es: No se pudo cargar el archivo del proyecto. Un nombre no puede empezar con el carácter '<', valor hexadecimal 0x3C. línea 46, posición 2.  Proyecto-Hada\library\library.csproj
- Es urgente que solucionéis esto ya que el proyecto lo tengo que poder descargar, abrir y ejecutar sin problemas.

## Requisitos EN
- Aseguraros de cumplir con los requisitos, cada miembro debe implementar dos EN o una en y sustituirlo por un servicio adicional. Recordad que en la entrega final, tendréis que indicar quién ha hecho cada cosa.

Saludos y buen trabajo, seguid así!!!