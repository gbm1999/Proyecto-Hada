# HadaPop - Comentarios entrega 01


!!!Que tal equipo!!!

Vuestra propuesta de HADAPOP me parece estupenda, puede dar mucho de si y es un proyecto apasionante.

Respecto de los requisitos de esta primera entrega, esta todo correcto y cumple con las especificaciones, sólamente faltaria el DNI.

Respecto de las entidades, en principio no encuentro ningún problema y todas son correctas.

Y nada más, muchas gracias por vuestra propuesta y estoy deseando empezar a ver cómo evoluciona.

Un saludo!!!!

